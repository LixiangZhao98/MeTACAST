var indexSectionsWithContent =
{
  0: "acdeghikmoprsuv",
  1: "u",
  2: "u",
  3: "acdgioprs",
  4: "acdehikmsuv",
  5: "ps"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "namespaces",
  3: "functions",
  4: "properties",
  5: "events"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Namespaces",
  3: "Functions",
  4: "Properties",
  5: "Events"
};

